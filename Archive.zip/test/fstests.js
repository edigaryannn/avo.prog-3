var obj = 
{
    "first_name": "Gor",
    "last_name": "Edigaryan",
    "age": 16,
    "tumo_student": true
}