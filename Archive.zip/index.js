var Square = require("./module");
var mySquareObject = new Square(5);

function main() {
    console.log(mySquareObject.getArea());
}

main();